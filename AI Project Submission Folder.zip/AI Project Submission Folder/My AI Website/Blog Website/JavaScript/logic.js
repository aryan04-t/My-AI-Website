function fun1(){
    alert("Basic Pack is Successfully Added To Your Cart");
}

function fun2(){
    alert("Pro Pack is Successfully Added To Your Cart");
}

function fun3(){
    alert("Advance Pack is Successfully Added To Your Cart");
}