const video = document.getElementById("video");
let predictedAges = [];

Promise.all([
  faceapi.nets.ssdMobilenetv1.loadFromUri("../models"),
  faceapi.nets.faceRecognitionNet.loadFromUri("../models"),
  faceapi.nets.faceLandmark68Net.loadFromUri("../models"),
  faceapi.nets.faceExpressionNet.loadFromUri('../models'),
  faceapi.nets.ageGenderNet.loadFromUri("../models"),
])
  .then(startWebcam)
  .then(faceRecognition);

function startWebcam() {
  navigator.mediaDevices
    .getUserMedia({
      video: true,
      audio: false,
    })
    .then((stream) => {
      video.srcObject = stream;
    })
    .catch((error) => {
      console.error(error);
    });
}

function getLabeledFaceDescriptions() {
  const labels = ["Aryan Tomar"];
  return Promise.all(
    labels.map(async (label) => {
      const descriptions = [];
      for (let i = 1; i <= 2; i++) {
        const img = await faceapi.fetchImage(`../labels/${label}/${i}.png`);
        const detections = await faceapi
          .detectSingleFace(img)
          .withFaceLandmarks()
          .withFaceDescriptor();
        descriptions.push(detections.descriptor);
      }
      return new faceapi.LabeledFaceDescriptors(label, descriptions);
    })
  );
}

async function faceRecognition() {
  const labeledFaceDescriptors = await getLabeledFaceDescriptions();
  const faceMatcher = new faceapi.FaceMatcher(labeledFaceDescriptors);
  
    video.addEventListener("playing", () => {
    location.reload();
  });

    const canvas = faceapi.createCanvasFromMedia(video);
    document.body.append(canvas);

    const displaySize = { width: video.width, height: video.height };
    faceapi.matchDimensions(canvas, displaySize);

    setInterval(async () => {
      const detections = await faceapi
        .detectAllFaces(video)
        .withFaceLandmarks()
        .withFaceDescriptors()
        .withFaceExpressions()
        .withAgeAndGender();

      const resizedDetections = faceapi.resizeResults(detections, displaySize);

      canvas.getContext("2d", {willReadFrequently: true}).clearRect(0, 0, canvas.width, canvas.height);

      const results = resizedDetections.map((d) => {
        return faceMatcher.findBestMatch(d.descriptor);
      });
      results.forEach((result, i) => {
        const box = resizedDetections[i].detection.box;
        const drawBox = new faceapi.draw.DrawBox(box, {
          label: result,
        });
        drawBox.draw(canvas);

        const Age = resizedDetections[0].age;
        const interpolatedAge = interpolateAgePredictions(Age);

        const bottomRight = {
          x: resizedDetections[0].detection.box.bottomLeft.x,
          y: resizedDetections[0].detection.box.bottomLeft.y + 36
        }

        new faceapi.draw.DrawTextField(
          [`Age: ${faceapi.utils.round(interpolatedAge, 0)} years`],
          bottomRight
        ).draw(canvas);

        const Gender = resizedDetections[0].gender;

        const bottomRight2 = {
          x: resizedDetections[0].detection.box.bottomLeft.x,
          y: resizedDetections[0].detection.box.bottomLeft.y + 56
        }

        new faceapi.draw.DrawTextField(
          [`Gender: ${Gender}`],
          bottomRight2
        ).draw(canvas);
      });

      faceapi.draw.drawFaceExpressions(canvas, resizedDetections);
      // faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);    // ---> Draws Face LandMarks

    }, 100);
}



function interpolateAgePredictions(age) {
  predictedAges = [age].concat(predictedAges).slice(0, 30);
  const avgPredictedAge = predictedAges.reduce((total, a) => total + a, 0) / predictedAges.length - 7;
  return avgPredictedAge;
}