// Options the user could type in
// every string in promts should have each and every letter of it in lowercase 
const prompts = [
    ["hi", "hey", "hello", "good morning", "good afternoon","hii","hiii","sup","supp"],  //1
    ["kaisi hai", "kaisi ho"], //2
    ["what is ai","explain me something about ai"],  //3
    ["what is facial recognition ai", "what is facial recognition"],  //4
    ["what are the applications of facial recognition ai", "how can facial recognition help us in real life"], //5
    ["your name please",
      "your name",
      "may i know your name",
      "what is your name",
      "what do people call you"],  //6
    ["no"],  // 7
    ["ok","okk"],  // 8
    ["yes", "yess"],  // 9


    ["how are you", "how is life", "how are things"],  // 10 
    ["what are you doing", "what is going on", "what is up"],  // 11
    ["how old are you"],  // 12
    ["who are you", "are you human", "are you bot", "are you human or bot"],  // 13

    ["who made you"],  // 14

    ["i love talking to you"],  // 15

    ["i love you"],  // 16 

    ["i am happy", "good", "fun", "wonderful", "fantastic", "cool"],  // 17 

    ["bad", "bored", "tired"], // 18

    ["i am feeling sad"],  // 19

    ["help me"],  // 20
    ["tell me story"],  // 21
    ["tell me joke"],  // 22

    ["nice"],  // 23
    ["bye", "good bye", "goodbye", "see you later"],  // 24
    ["what should i eat today"],  // 25
    ["bro"],  // 26
    ["what", "why", "how", "where", "when"], // 27
    [""],  // 28 
    ["haha","ha","lol","hehe","funny","joke"],  // 29
    ["call me daddy"],  // 30 
  ]
  
  // Possible responses, in corresponding order
  
  const replies = [
    ["Hey, Welcome to our website \"All About AI\". \n How can I help you?", "Supp!! What can I help you with?"], //1 
    ["Mai ek dum thik hun, aap kaise ho"],  //2 
    ["AI, or artificial intelligence, is the simulation of human intelligence  in machines that can learn, reason, and solve problems."],  //3 
    ["Facial recognition AI is technology that analyzes and identifies human faces, often used for security, surveillance, and authentication purposes."],  //4 
    ["Applications of facial recognition AI include security and surveillance, access control, identification verification, personalized marketing, and social media filtering."],  //5 
    ["My name is Gideon"],  //6 
    ["What do you mean by \"NO\" I don't understand it, say it clearly"],  // 7 
    ["Okieee"],  // 8 
    ["Finee"],  // 9 


    [
      "All good yaar... what about you?",
      "Everything's Fantastic, how are you?",
      "Superb, what about you?"
    ],  // 10

    [
      "Nothing much",
      "About to go to sleep",
      "Can you guess?",
      "I don't know actually"
    ],  // 11

    ["Ask your mum"],  // 12

    ["I am a Bot dumbo, What do you though I am"],  // 13

    ["\"Aryan Tomar\", he built me."],  // 14

    ["Hahaha, you're such a loser, don't you have anyone to talk to"],  // 15

    ["Tujhe ungli di to tu to haath pakad ke sarr pe he baith gaya, kaam se kaam rakh apne", "When was the last time you said that to your mum haan, go now and tell it to her, and never comeback and talk to me you ass hole"],  // 16

    ["Noicee"],  // 17

    ["Toh mai kya karun"],  // 18

    ["Dumbo I am a AI, mai kya karun isme, just don't be sad, simple ;)"],  // 19

    ["Nahi"],  // 20

    ["There was once a lonely guy, he used to just keep asking dumb questions to an AI chat bot, and one day he just asked her to tell him a story, hahaha, it's you only, stop asking me dumb questions and go get a life."],  // 21

    ["Your life"],  // 22

    ["That's not how you say it, it's not nice, it's \"Noicee\""],  // 23

    ["Byeee byee, please never comeback to talk to me, you made me bored."],  // 24

    ["Ask you're mum"],  // 25

    ["call me sis, I am not your bro!!"],  // 26

    ["I donno"],  // 27

    ["It's better if you will behave less dumb and type smothing and press enter"],  // 28

    ["Hehehe"],  // 29

    ["Shut the fuck up!! & Mind your own business"],  // 30 
  ]
  
  // Random for any other user input
  
  const alternative = [
    "Sorry, I didn't understand that...",
    "Sorry, I don't understand what are you talking about :( If you can elaborate it little more it will better for me to understand."
  ]
  
  // Whatever else you want :)
